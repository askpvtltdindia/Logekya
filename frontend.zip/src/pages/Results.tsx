import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Legend } from 'recharts';
import { CheckCircle, Shield, Cpu, TrendingUp, Rocket, Clock, Brain, Cloud, Lock, User, Code, BookOpen, Lightbulb, Github, Code2, GitBranch, Star, Mail, MapPin, GraduationCap } from 'lucide-react';

const Results = () => {
  // Sample data for charts
  const accuracyData = [
    { name: 'Random Forest', accuracy: 97.5, fill: 'hsl(150, 100%, 50%)' },
    { name: 'SVM', accuracy: 95.2, fill: 'hsl(185, 100%, 50%)' },
  ];

  const metricsData = [
    { metric: 'Precision', RF: 97.8, SVM: 94.5 },
    { metric: 'Recall', RF: 96.9, SVM: 95.8 },
    { metric: 'F1-Score', RF: 97.3, SVM: 95.1 },
    { metric: 'Accuracy', RF: 97.5, SVM: 95.2 },
  ];

  const confusionData = [
    { name: 'True Positive', value: 4850, color: 'hsl(150, 100%, 50%)' },
    { name: 'True Negative', value: 4720, color: 'hsl(185, 100%, 50%)' },
    { name: 'False Positive', value: 125, color: 'hsl(330, 100%, 50%)' },
    { name: 'False Negative', value: 155, color: 'hsl(30, 100%, 50%)' },
  ];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-primary/30 rounded-lg p-3 shadow-lg">
          <p className="text-foreground font-medium">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {entry.value}%
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const conclusions = [
    {
      icon: Shield,
      title: 'Effective Detection',
      description: 'Both Random Forest and SVM demonstrate high effectiveness in detecting various types of intrusions in IoT networks.',
    },
    {
      icon: TrendingUp,
      title: 'High Performance',
      description: 'Random Forest achieved 97.5% accuracy, showing exceptional capability in classifying normal and malicious traffic.',
    },
    {
      icon: Cpu,
      title: 'IoT Suitability',
      description: 'The lightweight nature of these algorithms makes them suitable for deployment in resource-constrained IoT environments.',
    },
  ];

  const futureWork = [
    {
      icon: Clock,
      title: 'Real-time Deployment',
      description: 'Implementing the IDS for real-time network traffic monitoring and instant threat detection in production IoT environments.',
      status: 'Next Phase',
      color: 'text-primary',
      bgColor: 'bg-primary/10',
      borderColor: 'border-primary/30',
    },
    {
      icon: Brain,
      title: 'Deep Learning Integration',
      description: 'Exploring deep learning models like LSTM and CNN for improved pattern recognition and zero-day attack detection.',
      status: 'Research',
      color: 'text-neon-green',
      bgColor: 'bg-neon-green/10',
      borderColor: 'border-neon-green/30',
    },
    {
      icon: Cpu,
      title: 'Edge Device Security',
      description: 'Optimizing models for direct deployment on edge devices and IoT gateways for decentralized threat detection.',
      status: 'Development',
      color: 'text-neon-magenta',
      bgColor: 'bg-neon-magenta/10',
      borderColor: 'border-neon-magenta/30',
    },
    {
      icon: Cloud,
      title: 'Cloud-Edge Hybrid',
      description: 'Developing a hybrid architecture combining edge computing with cloud-based advanced analytics.',
      status: 'Planned',
      color: 'text-neon-purple',
      bgColor: 'bg-neon-purple/10',
      borderColor: 'border-neon-purple/30',
    },
    {
      icon: Lock,
      title: 'Federated Learning',
      description: 'Implementing federated learning to train models across multiple IoT networks while preserving data privacy.',
      status: 'Future',
      color: 'text-primary',
      bgColor: 'bg-primary/10',
      borderColor: 'border-primary/30',
    },
  ];

  const teamMembers = [
    {
      name: 'SHUBHAM KUMAR',
      role: 'Project Lead',
      icon: Lightbulb,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
      borderColor: 'border-primary/30',
      isLead: true,
    },
    {
      name: 'ASHISH RANJAN',
      role: 'Team Member',
      icon: Code,
      color: 'text-neon-green',
      bgColor: 'bg-neon-green/10',
      borderColor: 'border-neon-green/30',
    },
    {
      name: 'SACHIN KR YADAV',
      role: 'Team Member',
      icon: BookOpen,
      color: 'text-neon-magenta',
      bgColor: 'bg-neon-magenta/10',
      borderColor: 'border-neon-magenta/30',
    },
    {
      name: 'MANIKANT',
      role: 'Team Member',
      icon: Code,
      color: 'text-neon-purple',
      bgColor: 'bg-neon-purple/10',
      borderColor: 'border-neon-purple/30',
    },
  ];

  return (
    <div className="pt-16">
      {/* Results Charts Section */}
      <section className="py-24 relative bg-secondary/30">
        <div className="container mx-auto px-4">
          {/* Section Header */}
          <div className="text-center mb-16 fade-in-up">
            <span className="font-mono text-primary text-sm tracking-wider uppercase mb-4 block">
              [ Results & Graphs ]
            </span>
            <h2 className="font-display text-3xl md:text-5xl font-bold mb-6">
              Performance <span className="gradient-text">Analysis</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
              Comprehensive evaluation metrics demonstrating the effectiveness of our intrusion detection models.
            </p>
          </div>

          {/* Charts Grid */}
          <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Accuracy Comparison */}
            <div className="cyber-card p-6 fade-in-up stagger-1">
              <h3 className="font-display text-xl font-bold mb-6 text-foreground flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                Model Accuracy Comparison
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={accuracyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(185, 50%, 20%)" />
                    <XAxis dataKey="name" tick={{ fill: 'hsl(180, 20%, 60%)' }} />
                    <YAxis domain={[90, 100]} tick={{ fill: 'hsl(180, 20%, 60%)' }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="accuracy" radius={[8, 8, 0, 0]}>
                      {accuracyData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Confusion Matrix Pie */}
            <div className="cyber-card p-6 fade-in-up stagger-2">
              <h3 className="font-display text-xl font-bold mb-6 text-foreground flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
                Confusion Matrix Distribution
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={confusionData}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={80}
                      paddingAngle={2}
                      dataKey="value"
                    >
                      {confusionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(240, 10%, 6%)', 
                        border: '1px solid hsl(185, 50%, 20%)',
                        borderRadius: '8px'
                      }}
                    />
                    <Legend 
                      formatter={(value) => <span style={{ color: 'hsl(180, 20%, 60%)' }}>{value}</span>}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Performance Metrics Comparison */}
            <div className="cyber-card p-6 lg:col-span-2 fade-in-up stagger-3">
              <h3 className="font-display text-xl font-bold mb-6 text-foreground flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-neon-magenta animate-pulse" />
                Precision, Recall & F1-Score Comparison
              </h3>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={metricsData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(185, 50%, 20%)" />
                    <XAxis dataKey="metric" tick={{ fill: 'hsl(180, 20%, 60%)' }} />
                    <YAxis domain={[90, 100]} tick={{ fill: 'hsl(180, 20%, 60%)' }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend 
                      formatter={(value) => <span style={{ color: 'hsl(180, 100%, 95%)' }}>{value}</span>}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="RF" 
                      name="Random Forest"
                      stroke="hsl(150, 100%, 50%)" 
                      strokeWidth={3}
                      dot={{ fill: 'hsl(150, 100%, 50%)', r: 6 }}
                      activeDot={{ r: 8 }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="SVM" 
                      name="SVM"
                      stroke="hsl(185, 100%, 50%)" 
                      strokeWidth={3}
                      dot={{ fill: 'hsl(185, 100%, 50%)', r: 6 }}
                      activeDot={{ r: 8 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Key Findings */}
          <div className="mt-12 max-w-4xl mx-auto fade-in-up">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="cyber-card p-6 text-center hover-lift">
                <div className="text-4xl font-display font-bold text-neon-green neon-text-green mb-2">97.5%</div>
                <p className="text-muted-foreground text-sm">Random Forest Accuracy</p>
              </div>
              <div className="cyber-card p-6 text-center hover-lift">
                <div className="text-4xl font-display font-bold text-primary neon-text-cyan mb-2">95.2%</div>
                <p className="text-muted-foreground text-sm">SVM Accuracy</p>
              </div>
              <div className="cyber-card p-6 text-center hover-lift">
                <div className="text-4xl font-display font-bold text-neon-magenta neon-text-magenta mb-2">10K+</div>
                <p className="text-muted-foreground text-sm">Samples Tested</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Conclusion Section */}
      <section className="py-24 relative">
        <div className="container mx-auto px-4">
          {/* Section Header */}
          <div className="text-center mb-16 fade-in-up">
            <span className="font-mono text-primary text-sm tracking-wider uppercase mb-4 block">
              [ Conclusion ]
            </span>
            <h2 className="font-display text-3xl md:text-5xl font-bold mb-6">
              Project <span className="gradient-text">Conclusion</span>
            </h2>
          </div>

          {/* Main Conclusion */}
          <div className="max-w-4xl mx-auto">
            <div className="cyber-card p-8 md:p-12 mb-12 fade-in-up stagger-1">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-12 h-12 rounded-lg bg-neon-green/10 border border-neon-green/20 flex items-center justify-center flex-shrink-0">
                  <CheckCircle className="w-6 h-6 text-neon-green" />
                </div>
                <div>
                  <h3 className="font-display text-xl font-bold text-foreground mb-2">
                    Summary of Findings
                  </h3>
                </div>
              </div>

              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  This project successfully demonstrates the effectiveness of machine learning-based intrusion detection systems for IoT environments. Through the implementation and evaluation of Random Forest and Support Vector Machine algorithms, we have shown that these lightweight yet powerful techniques can accurately identify and classify various types of cyber attacks targeting IoT networks.
                </p>
                <p>
                  The experimental results on the Bot-IoT dataset validate that our approach achieves high detection accuracy while maintaining computational efficiency suitable for resource-constrained IoT devices. Random Forest emerged as the top performer with 97.5% accuracy, closely followed by SVM with 95.2% accuracy.
                </p>
                <p className="text-neon-green">
                  These findings contribute to the growing body of research aimed at securing the rapidly expanding IoT ecosystem against increasingly sophisticated cyber threats.
                </p>
              </div>
            </div>

            {/* Key Conclusions */}
            <div className="grid md:grid-cols-3 gap-6">
              {conclusions.map((item, index) => (
                <div
                  key={item.title}
                  className={`cyber-card p-6 hover-lift fade-in-up stagger-${index + 2}`}
                >
                  <div className="w-12 h-12 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center mb-4">
                    <item.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-display text-lg font-semibold mb-2 text-foreground">
                    {item.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Future Scope Section */}
      <section className="py-24 relative bg-secondary/30">
        <div className="container mx-auto px-4">
          {/* Section Header */}
          <div className="text-center mb-16 fade-in-up">
            <span className="font-mono text-primary text-sm tracking-wider uppercase mb-4 block">
              [ Future Scope ]
            </span>
            <h2 className="font-display text-3xl md:text-5xl font-bold mb-6">
              What's <span className="gradient-text">Next?</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
              Potential enhancements and future directions for extending this research.
            </p>
          </div>

          {/* Future Work Cards */}
          <div className="max-w-5xl mx-auto">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {futureWork.map((item, index) => (
                <div
                  key={item.title}
                  className={`cyber-card p-6 hover-lift fade-in-up stagger-${(index % 5) + 1} ${
                    index === 0 ? 'lg:col-span-2 md:col-span-2' : ''
                  }`}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-12 h-12 rounded-lg ${item.bgColor} border ${item.borderColor} flex items-center justify-center`}>
                      <item.icon className={`w-6 h-6 ${item.color}`} />
                    </div>
                    <span className={`px-3 py-1 rounded-full ${item.bgColor} border ${item.borderColor} ${item.color} text-xs font-medium`}>
                      {item.status}
                    </span>
                  </div>
                  <h3 className="font-display text-lg font-semibold mb-2 text-foreground">
                    {item.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>

            {/* Call to Action */}
            <div className="mt-16 text-center fade-in-up">
              <div className="inline-flex items-center gap-3 px-6 py-3 rounded-xl bg-gradient-to-r from-primary/10 to-neon-green/10 border border-primary/20">
                <Rocket className="w-6 h-6 text-primary animate-float" />
                <span className="text-foreground font-medium">
                  This research opens doors to advanced IoT security solutions
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-24 relative">
        <div className="container mx-auto px-4">
          {/* Section Header */}
          <div className="text-center mb-16 fade-in-up">
            <span className="font-mono text-primary text-sm tracking-wider uppercase mb-4 block">
              [ Team Members ]
            </span>
            <h2 className="font-display text-3xl md:text-5xl font-bold mb-6">
              Meet Our <span className="gradient-text">Team</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
              The talented individuals who contributed to this project.
            </p>
          </div>

          {/* Team Grid */}
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {teamMembers.map((member, index) => (
                <div
                  key={member.name}
                  className={`cyber-card p-6 text-center hover-lift fade-in-up stagger-${index + 1} ${
                    member.isLead ? 'lg:col-span-4 md:col-span-2' : ''
                  }`}
                >
                  {/* Avatar */}
                  <div className={`w-20 h-20 mx-auto rounded-full ${member.bgColor} border-2 ${member.borderColor} flex items-center justify-center mb-4 ${member.isLead ? 'w-24 h-24' : ''}`}>
                    <member.icon className={`${member.isLead ? 'w-10 h-10' : 'w-8 h-8'} ${member.color}`} />
                  </div>

                  {/* Name */}
                  <h3 className={`font-display font-bold mb-1 text-foreground ${member.isLead ? 'text-xl' : 'text-lg'}`}>
                    {member.name}
                  </h3>

                  {/* Role Badge */}
                  <span className={`inline-block px-3 py-1 rounded-full ${member.bgColor} border ${member.borderColor} ${member.color} text-xs font-medium`}>
                    {member.role}
                  </span>

                  {/* Lead Badge */}
                  {member.isLead && (
                    <div className="mt-4 pt-4 border-t border-border">
                      <p className="text-muted-foreground text-sm">
                        Department of Computer Science & Engineering
                      </p>
                      <p className="text-primary text-sm font-mono mt-1">
                        LNJPIT, Chapra | 7th Semester
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Guide Info */}
            <div className="mt-12 text-center fade-in-up">
              <div className="inline-block cyber-card px-8 py-6">
                <div className="flex items-center justify-center gap-3 mb-3">
                  <User className="w-8 h-8 text-neon-green" />
                  <span className="font-display text-xl font-bold text-foreground">Project Guide</span>
                </div>
                <p className="text-2xl font-display font-bold text-neon-green neon-text-green">
                  SHUDHIR SIR
                </p>
                <p className="text-muted-foreground text-sm mt-2">
                  Faculty Advisor, CSE Department
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* GitHub Section */}
      <section className="py-24 relative bg-secondary/30">
        <div className="container mx-auto px-4">
          {/* Section Header */}
          <div className="text-center mb-16 fade-in-up">
            <span className="font-mono text-primary text-sm tracking-wider uppercase mb-4 block">
              [ Source Code ]
            </span>
            <h2 className="font-display text-3xl md:text-5xl font-bold mb-6">
              <span className="gradient-text">GitHub</span> Repository
            </h2>
          </div>

          {/* GitHub Card */}
          <div className="max-w-2xl mx-auto">
            <div className="cyber-card p-8 text-center hover-lift fade-in-up stagger-1">
              {/* GitHub Icon */}
              <div className="w-20 h-20 mx-auto rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mb-6">
                <Github className="w-10 h-10 text-primary" />
              </div>

              <h3 className="font-display text-2xl font-bold text-foreground mb-2">
                IoT-IDS-ML
              </h3>
              <p className="text-muted-foreground mb-6">
                Smart IoT Intrusion Detection using Random Forest & SVM
              </p>

              {/* Stats */}
              <div className="flex justify-center gap-6 mb-8">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Code2 className="w-4 h-4" />
                  <span className="text-sm">Python</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Star className="w-4 h-4" />
                  <span className="text-sm">Star</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <GitBranch className="w-4 h-4" />
                  <span className="text-sm">Fork</span>
                </div>
              </div>

              {/* Coming Soon Badge */}
              <div className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-primary/10 border border-primary/30">
                <span className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
                <span className="font-mono text-primary">Repository Coming Soon</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-24 relative">
        <div className="container mx-auto px-4">
          {/* Section Header */}
          <div className="text-center mb-16 fade-in-up">
            <span className="font-mono text-primary text-sm tracking-wider uppercase mb-4 block">
              [ Contact ]
            </span>
            <h2 className="font-display text-3xl md:text-5xl font-bold mb-6">
              Get In <span className="gradient-text">Touch</span>
            </h2>
          </div>

          {/* Contact Cards */}
          <div className="max-w-4xl mx-auto grid md:grid-cols-3 gap-6">
            <div className="cyber-card p-6 text-center hover-lift fade-in-up stagger-1">
              <div className="w-14 h-14 mx-auto rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center mb-4">
                <GraduationCap className="w-7 h-7 text-primary" />
              </div>
              <h3 className="font-display font-semibold text-foreground mb-2">Institution</h3>
              <p className="text-muted-foreground text-sm">
                Loknayak Jai Prakash Institute of Technology
              </p>
              <p className="text-primary text-sm font-mono mt-1">LNJPIT, Chapra</p>
            </div>

            <div className="cyber-card p-6 text-center hover-lift fade-in-up stagger-2">
              <div className="w-14 h-14 mx-auto rounded-xl bg-neon-green/10 border border-neon-green/20 flex items-center justify-center mb-4">
                <MapPin className="w-7 h-7 text-neon-green" />
              </div>
              <h3 className="font-display font-semibold text-foreground mb-2">Department</h3>
              <p className="text-muted-foreground text-sm">
                Computer Science & Engineering
              </p>
              <p className="text-neon-green text-sm font-mono mt-1">7th Semester</p>
            </div>

            <div className="cyber-card p-6 text-center hover-lift fade-in-up stagger-3">
              <div className="w-14 h-14 mx-auto rounded-xl bg-neon-magenta/10 border border-neon-magenta/20 flex items-center justify-center mb-4">
                <Mail className="w-7 h-7 text-neon-magenta" />
              </div>
              <h3 className="font-display font-semibold text-foreground mb-2">Contact</h3>
              <p className="text-muted-foreground text-sm">
                For project inquiries
              </p>
              <p className="text-neon-magenta text-sm font-mono mt-1">Via College</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Results;
